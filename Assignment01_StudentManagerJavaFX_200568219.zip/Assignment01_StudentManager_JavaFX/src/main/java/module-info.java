module org.example.assignment01_studentmanager_javafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.assignment01_studentmanager_javafx to javafx.fxml;
    exports org.example.assignment01_studentmanager_javafx;
}