package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Student;

import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML
    private TableView<Student> studentTableView;
    @FXML
    private TableColumn<Student, Integer> idColumn;
    @FXML
    private TableColumn<Student, String> nameColumn;
    @FXML
    private TableColumn<Student, String> emailColumn;
    @FXML
    private TableColumn<Student, String> majorColumn;

    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField majorField;

    @FXML
    private Button addButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button deleteButton;

    private ObservableList<Student> studentData = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        majorColumn.setCellValueFactory(new PropertyValueFactory<>("major"));

        // Load initial data (replace with your data loading logic)
        studentData.addAll(
                new Student(1, "John Doe", "john.doe@example.com", "Computer Science"),
                new Student(2, "Jane Smith", "jane.smith@example.com", "Business Administration")
        );

        // Set data to the table
        studentTableView.setItems(studentData);

        // Add button functionality (add a new student to the list)
        addButton.setOnAction(event -> {
            // Get data from fields
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String email = emailField.getText();
            String major = majorField.getText();

            // Create new student object and add to the list
            Student newStudent = new Student(id, name, email, major);
            studentData.add(newStudent);

            // Clear fields
            idField.clear();
            nameField.clear();
            emailField.clear();
            majorField.clear();
        });

        // Update button functionality (update selected student in the list)
        updateButton.setOnAction(event -> {
            // Get selected student from the table
            Student selectedStudent = studentTableView.getSelectionModel().getSelectedItem();

            // Update student data if a student is selected
            if (selectedStudent != null) {
                selectedStudent.setName(nameField.getText());
                selectedStudent.setEmail(emailField.getText());
                selectedStudent.setMajor(majorField.getText());

                // Update table data
                studentTableView.refresh();
            }
        });

        // Delete button functionality (delete selected student from the list)
        deleteButton.setOnAction(event -> {
            // Get selected student from the table
            Student selectedStudent = studentTableView.getSelectionModel().getSelectedItem();

            // Delete student from the list if a student is selected
            if (selectedStudent != null) {
                studentData.remove(selectedStudent);
            }
        });
    }
}